
<!DOCTYPE html>
    <html>
    <head><title>Page Connexion</title></head>
    <body>
   <h1>Connexion</h1>
               
   <?php
    $pseudo  =isset($_POST["pseudo"])?$_POST["pseudo"]:"";  
    $password = isset($_POST["password"])?$_POST["password"]:"";
        
    if(isset($_POST['submit']))
    {
    //Blindage de la saisie des infos
    

    if(empty($pseudo)){$erreurs[] ="Saisir votre pseudo<br/>";}
    if(empty($password)){$erreurs[]="Saisir votre password";}
    if(!empty($erreurs))
        {
            foreach($erreurs as $erreur)
            {
                echo "<div class='erreur'>".$erreur."</div>";
            }
        }
    }
    if(isset($_POST['submit']) && empty($erreurs))
    {
    $database = "piscine";
    
    $db_handle = mysqli_connect('localhost', 'root','root');
    $db_found = mysqli_select_db($db_handle, $database);

    if($db_found)
    {
        $sql = "SELECT * FROM utilisateurs where pseudo='$pseudo' and password='$password'";
        $resultat = mysqli_query($db_handle, $sql);
        if(mysqli_num_rows($result)==0)
        {
            session_start();
            $_SESSION['auth']='true';
            header('location:acceuil.html');
       }
        else
        {
            echo' pseudo ou password incorrect';
        }
    }
    else 
    {
        echo"Database not found.";
    }
    
    mysqli_close($db_handle);
        
    }

    ?>

<form method="POST" action="">

    <label for="pseudo">pseudo </label>
    <input type="text" name="pseudo"><br/>
    <label for="password">password </label>
    <input type="password" name="password"><br/><br/>
    <input type="submit" value="Se connecter" name="submit">
    
    
</form>

<a href="index.php?page=register">S'inscire</a>
</body>
</html>