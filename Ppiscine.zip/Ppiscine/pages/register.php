<h1>Inscription</h1>
<?php


    $pseudo  =isset($_POST["pseudo"])?$_POST["pseudo"]:"";
    $password = isset($_POST["password"])?$_POST["password"]:"";
    $repeatpassword= isset($_POST["repeatpassword"])?$_POST["repeatpassword"]:"";
    $email = isset($_POST["email"])?$_POST["email"]:"";
    $tel= isset($_POST["tel"])?$_POST["tel"]:"";
    $adresse= isset($_POST["adresse"])?$_POST["adresse"]:"";
    $prenom= isset($_POST["prenom"])?$_POST["prenom"]:"";
    $nom= isset($_POST["nom"])?$_POST["nom"]:"";
    $sex= isset($_POST["sexe"])?$_POST["sexe"]:"";

  
function inscire($email,$nom,$prenom,$pseudo,$tel,$adresse,$password,$sex)
{
    global $db_handle;
     $sql = "INSERT INTO utilisateurs (email, nom, prenom,pseudo,tel,adresse,password,sex) VALUES ('$email','$nom','$prenom','$pseudo','$tel','$adresse','$password','$sex')";
    $result = mysqli_query($db_handle, $sql);
    echo "Add successful";
}


/*function pseudo_exists($pseudo)
{
    $deja='SELECT COUNT(id)FROM utilisateurs WHERE pseudo='$pseudo'';
    return mysql_result($deja,0);
}
*/
    
      

    if(isset($_POST['submit']))
    {
    //Blindage de la saisie des infos
        
    if(empty($prenom)){$erreurs[] ="Veuillez saisir votre prenom";}
    if(empty($nom)){$erreurs[] ="Veuillez saisir votre nom";}
    if(empty($pseudo)){$erreurs[] ="Veuillez saisir un nouveau pseudo";}
    if(empty($password)){$erreurs[]="Veuillez saisir un nouveau password";}
    if($password!=$repeatpassword){$erreurs[]="Vos passwords doivent être identiques";}
    if(!filter_var($email,FILTER_VALIDATE_EMAIL)){$erreurs[]="Veuillez saisir votre adresse email";}
    if(empty($tel)){$erreurs[]="Veuillez saisir votre numero de telephone portable";}
    if(empty($adresse)){$erreurs[]="Veuillez saisir votre adresse";}
    
     if(!empty($erreurs))
     {
            foreach($erreurs as $erreur)
            {
                echo "<div class='erreur'>".$erreur."</div>";
            }
    
     }
     
}
if(isset($_POST["submit"]) && empty($erreurs)){
  $database = "piscine";
//connecter l'utilisateur dans BDD
    $db_handle = mysqli_connect('localhost','root','root'); 
    $db_found = mysqli_select_db($db_handle, $database);
    
    

//si BDD existe 
    if ($db_found) {
        
        inscire($email,$nom,$prenom,$pseudo,$tel,$adresse,$password,$sex);
        
        //echo pseudo_exists($pseudo);
             
        
} else 
    {
        
        echo "Database not found.";
       
 }
    
//fermer la connection
mysqli_close($db_handle);}
    
    

?>


<form method="POST" action="">

    <label for="sexe">Sexe</label>
    <select name="sexe">
        
             
    <option value="Masculin">Masculin</option>
     <option value="Feminin">Feminin</option>
            
    
    </select><br/><br/>
    
    <label for="prenom">Prenom</label>
    <input type="prenom"name="prenom"><br/><br/>
    
    <label for="nom">Nom</label>
    <input type="nom"name="nom"><br/><br/>
    
    <label for="pseudo">Pseudo</label>
    <input type="text"name="pseudo"><!--value='<?php echo isset($pseudo)?$pseudo:'';?>'>--><br/><br/>
    
    <label for="password">Password</label>
    <input type="password"name="password"><br/><br/>
    
    <label for="repeatpassword">Repeat password</label>
    <input type="password"name="repeatpassword"><br/><br/>
    
    <label for="email">Email</label>
    <input type="text"name="email" value='<?php echo isset($email)?$email:'';?>'><br/><br/>
    
    <label for="tel"> Tél </label>
    <input type="tel"name="tel"><br/><br/>
    
    <label for="adresse">Adresse</label>
    <input type="texte"name="adresse"><br/>
    
     
    <input type="submit"value="S'inscrire" name="submit">
    
</form>


<a href="index.php?page=login">Se connecter</a>



    
    