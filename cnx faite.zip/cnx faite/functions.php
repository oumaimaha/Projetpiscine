<?php

/*try
{
    $bdd = new PDO('mysql:host=localhost;dbname=piscine;charset=utf8', 'root', 'root');
    
}

catch (Exception $e)
{
        die('Erreur : ' . $e->getMessage());
}

$req = $bdd->prepare('INSERT INTO utilisateurs(email,nom,prenom,pseudo,tel,adresse,password,sex) VALUES(:email,:nom,:prenom,:pseudo,:tel,:adresse,:password,:sex)');

$req->execute(array(
    'email' => $email,
    'nom' => $nom,
    'prenom' => $prenom,
    'pseudo' => $pseudo,
    'tel' => $adresse,
    'password' => $password,
    'sex' => $sex,
    ));*/





//Connexion a la base de donnée piscine
/*
$database = "piscine";
        //connecter l'utilisateur dans BDD
            $db_handle = mysqli_connect('localhost','root','root'); 
            $db_found = mysqli_select_db($db_handle, $database);
            if ($db_found) {
                function inscrire_utilisateur($email,$nom,$prenom,$pseudo,$tel,$adresse,$password,$sex){
            $sql = "INSERT INTO utilisateurs (email, nom, prenom, pseuso,tel,adresse,password,sex) VALUES ('',$email', '$nom', '$prenom', '$pseudo','$tel','$adresse','$password','$sex')";}
            $result = mysqli_query($db_handle, $sql); echo "Add successful.";} 
            else {echo "Database not found."; }}
    //fermer la connection
    mysqli_close($db_handle);


//fonction qui va se charger d'inscrire un nouvel utlisateur

/*function inscrire_utilisateur($email,$nom,$prenom,$pseudo,$tel,$adresse,$password,$sex)
{
    $sql='INSERT INTO utilisateurs(id,email,nom,prenom,pseudo,tel,adresse,password,sex)
    VALUES('','$email','$nom','$prenom','$pseudo','$tel','$adresse','$password','$sex')';
    
    $password = sha1($password);
    
    mysqli_query($db_handle,$sql) or die('erreur'); // fonction qui accede a l'identificateur de la connection et a la requete precedente
    
    echo ('Nouvel utilisateur ajouté !');
    
    mysqli_close($db_handle);
    
}




*/


?>


