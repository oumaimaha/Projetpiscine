<h1>Inscription</h1>
<?php


    $pseudo  =isset($_POST["pseudo"])?$_POST["pseudo"]:"";//if then else
    $password = isset($_POST["password"])?$_POST["password"]:"";
    $repeatpassword= isset($_POST["repeatpassword"])?$_POST["repeatpassword"]:"";
    $email = isset($_POST["email"])?$_POST["email"]:"";
    $tel= isset($_POST["tel"])?$_POST["tel"]:"";
    $adresse= isset($_POST["adresse"])?$_POST["adresse"]:"";
    $prenom= isset($_POST["prenom"])?$_POST["prenom"]:"";
    $nom= isset($_POST["nom"])?$_POST["nom"]:"";
    
        try{$bdd = new PDO('mysql:host=localhost;dbname=piscine;charset=utf8', 'root', 'root');}

        catch (Exception $e){die('Erreur : ' . $e->getMessage());}


    if(isset($_POST['submit']))
    {
    //Blindage de la saisie des infos
        
    if(empty($prenom)){$erreurs[] ="Veuillez saisir votre prenom";}
    if(empty($nom)){$erreurs[] ="Veuillez saisir votre nom";}
    if(empty($pseudo)){$erreurs[] ="Veuillez saisir un nouveau pseudo";}
    if(empty($password)){$erreurs[]="Veuillez saisir un nouveau password";}
    if($password!=$repeatpassword){$erreurs[]="Vos passwords doivent être identiques";}
    if(!filter_var($email,FILTER_VALIDATE_EMAIL)){$erreurs[]="Veuillez saisir votre adresse email";}
    if(empty($tel)){$erreurs[]="Veuillez saisir votre numero de telephone portable";}
    if(empty($adresse)){$erreurs[]="Veuillez saisir votre adresse";}
    
     if(!empty($erreurs))
     {
            foreach($erreurs as $erreur)
            {
                echo "<div class='erreur'>".$erreur."</div>";
            }
    
     }
     else
     {
    /*$pseudo  =isset($_POST["pseudo"])?$_POST["pseudo"]:"";//if then else
    $password = isset($_POST["password"])?$_POST["password"]:"";
    $repeatpassword= isset($_POST["repeatpassword"])?$_POST["repeatpassword"]:"";
    $email = isset($_POST["email"])?$_POST["email"]:"";
    $tel= isset($_POST["tel"])?$_POST["tel"]:"";
    $adresse= isset($_POST["adresse"])?$_POST["adresse"]:"";
    $prenom= isset($_POST["prenom"])?$_POST["prenom"]:"";
    $nom= isset($_POST["nom"])?$_POST["nom"]:"";*/

    $req = $bdd->prepare('INSERT INTO utilisateurs(email,nom,prenom,pseudo,tel,adresse,password,sex) VALUES(\'Battlefield 1942\', \'Patrick\', \'PC\', \'45\',\'erc\',\'edzze\',\'dezedze\')');
    /*$req->execute(array(
    'email' => $email,
    'nom' => $nom,
    'prenom' => $prenom,
    'pseudo' => $pseudo,
    'tel' => $adresse,
    'password' => $password,
    'sex' => $sex,
    ));*/
    echo 'Vous etes bien inscrits !';


         /*inscrire_utilisateur($email,$nom,$prenom,$pseudo,$tel,$adresse,$password,$sex);
         die('Inscription terminée, vous pouvez desormais vous <a href=\'index.php?page=login\'>conncecter</a>');*/
     }

}




   
    /*if(isset($_POST['submit']))
    {
        $sexe=mysql_real_escape_string(htmlspecialchars(trim($_POST['sexe'])));
        $pseudo=mysql_real_escape_string(htmlentities(trim($_POST['pseudo'])));
        $password=mysql_real_escape_string(htmlentities(trim($_POST['password'])));
        $repeatpassword=mysql_real_escape_string(htmlentities(trim($_POST['repeatpassword'])));
        $email=mysql_real_escape_string(htmlentities(trim($_POST['email'])));
        $tel=mysql_real_escape_string(htmlentities(trim($_POST['tel'])));
        $adresse=mysql_real_escape_string(htmlentities(trim($_POST['adresse'])));
       
        
        if(empty($pseudo))
        {
            $errors[]="Saisir votre pseudo";
        }
        
        if(empty($password))
        {
            $errors[]="Saisir votre password";
        }
        
        if($password!=$repeatpassword)
        {
            $errors[]="Vos passwords doivent être identiques";
        }
        
        if(!filter_var($email,FILTER_VALIDATE_EMAIL))
        {
            $errors[]="Adresse email incorrecte";
        }
        
        if(empty($tel))
        {
            $errors[]="Saisir votre numero de telephone";
        }
        
        if(empty($adresse))
        {
            $errors[]="Saisir votre adresse";
        }
        
        if(!empty($errors))
        {
            foreach($errors as $error)
            {
                echo "<div class='error'>".$error."</div>";
            }
        }else
        {
            inscrire_utilisateur($pseudo,$password,$email,$sexe,$tel,$adresse);
             die ('Vous êtes désormais inscrit, vous pouvez maintenant vous <a href=\'index.php?page=login\'>connecter</a>');
        }
            
    }*/
?>


<form method="POST" action="">

    <label for="sexe">Sexe</label>
    <select name="sexe">
        
             
    <option value="Masculin">Masculin</option>
     <option value="Feminin">Feminin</option>
            
    
    </select><br/><br/>
    
    <label for="prenom">Prenom</label>
    <input type="prenom"name="prenom"><br/><br/>
    
    <label for="nom">Nom</label>
    <input type="nom"name="nom"><br/><br/>
    
    <label for="pseudo">pseudo</label>
    <input type="text"name="pseudo"><!--value='<?php echo isset($pseudo)?$pseudo:'';?>'>--><br/><br/>
    
    <label for="password">password</label>
    <input type="password"name="password"><br/><br/>
    
    <label for="repeatpassword">Repetez votre password</label>
    <input type="password"name="repeatpassword"><br/><br/>
    
    <label for="email">email</label>
    <input type="text"name="email" value='<?php echo isset($email)?$email:'';?>'><br/><br/>
    
    <label for="tel">numero de telephone</label>
    <input type="tel"name="tel"><br/><br/>
    
    <label for="adresse">adresse</label>
    <input type="texte"name="adresse"><br/>
    
    
    
    
    <input type="submit"value="S'inscrire" name="submit">
    
</form>


<a href="index.php?page=login">Retour à la page de connexion</a>


    
    