<?php
session_start();
if(!$_SESSION['piscine'])
{
	header('Location:login.php');
echo" te voila";

?>

