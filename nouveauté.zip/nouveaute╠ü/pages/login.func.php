<?php
//la fonction qui vérifie la combin pseudo pass
/*function verifier_combinaison_pseudo_password($pseudo,$password){

	$pseudo  =isset($_POST["pseudo"])?$_POST["pseudo"]:"";//if then else
    $password = isset($_POST["password"])?$_POST["password"]:""; 
    $password=sha1($password);
    $query=mysql_query("SELECT pseudo, password From utilisateurs WHERE pseudo='$pseudo' AND password='$password'");
    $rows=mysql_num_rows($query);
    return $rows;
}