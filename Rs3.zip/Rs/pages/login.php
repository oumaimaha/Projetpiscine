<!DOCTYPE html>
    <html>
    <head><title>Page Connexion</title></head>
    <body>
   <h1>Connexion</h1>
   <?php
    $pseudo  =isset($_POST["pseudo"])?$_POST["pseudo"]:"";//if then else
    
    $password = isset($_POST["password"])?$_POST["password"]:"";
    if(isset($_POST['submit'])){
    //Blindage de la saisie des infos
    

    if(empty($pseudo)){$erreurs[] ="pseudo non renseigné<br/>";}
    if(empty($password)){$erreurs[]="Saisir votre password";}
      if(!empty($erreurs))
        {
            foreach($erreurs as $erreur)
            {
                echo "<div class='erreur'>".$erreur."</div>";
            }
        }}
    ?>

<form method="POST" action="">

    <label for="pseudo">pseudo : </label>
    <input type="text" name="pseudo"><br/>
    <label for="password">password : </label>
    <input type="password" name="password"><br/><br/>
    <input type="submit" value="Se connecter" name="submit">
    
    
</form>

<a href="index.php?page=register">S'inscire</a>
</body>
</html>