<?php
//recuperer les infos de l'utilisateur

function infos_membre_connecte(){
	$infos=array();
	$pseudo= $_SESSION ['pseudo'];
	$query+mysql_query("SELECT *FROM utilisateur WHERE pseudo ='$pseudo'");
	while($row=mysql_fetch_assoc($query)){
		$infos[]=$row;
	}
	return $infos;
}
//fonction qui compte le nombre de personne inscrites
function nombre_membre()
{
	$query=mysql_query("SELECT COUNT(id)FROM utilisateur");
	return mysql_result($query,0);
} 

?>