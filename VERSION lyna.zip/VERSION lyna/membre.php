<div class="header">
	<?php
	$infos =infos_membre_connecte();

	foreach($infos as $info)
	{
		echo"Bienvenue".$info['pseudo'];
	}
	if(!isset($_SESSION['pseudo']))
	{
		header("Location:index.php?page=login")
	}
	?>
	<p> <a href="index.php?page=logout">Se deconnecter</a></p>
</div> 
<div class='menu'>
	<ul>
		<li><a href="index.php?page=membre">Accueil</a></li>
		<li><a href="">Profil</a></li>
		<li><a href="">Réseau</a></li>
		<li><a href="">Notifications</a></li>
		<li><a href="">Messageries</a></li>
		<li class='nombre Amis'><?php echo nombre_membre()>1? nombre_membre().'membres': nombre_membre().'membre'; ?></li>

		</ul>
	</div>
	<div class="info">
		<?php
		foreach ($infos as $info) {
			?> 
			<P><strong>email</strong>:<em><?php echo $info['email'];?></em></P>
			<P><strong>Sex</strong>:<em><?php echo $info['Sex'];?></em></P>
			<P><strong>nom</strong>:<em><?php echo $info['nom'];?></em></P>
			<P><strong>prenom</strong>:<em><?php echo $info['prenom'];?></em></P>
			<P> <strong>tel</strong>:<em><?phpecho $info['tel'];?></em></P>
			<P> <strong>adresse</strong>:<em><?php echo $info['adresse'].?></em></P>
			


		}
	</div>
