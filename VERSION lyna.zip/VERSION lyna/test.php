<div class='menu'>
	<ul>
		<li><a href="index.php?page=membre">Accueil</a></li>
		<li><a href="">Profil</a></li>
		<li><a href="">Réseau</a></li>
		<li><a href="">Notifications</a></li>
		<li><a href="">Messageries</a></li>
		</ul>
	</div>