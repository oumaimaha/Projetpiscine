<div class="header">
	<?php
	$infos =infos_membre_connecte();

	foreach($infos as $info)
	{
		echo"Bienvenue".$info['pseudo'];
	}