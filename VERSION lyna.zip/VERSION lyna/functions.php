<?php

try
{
    $bdd = new PDO('mysql:host=localhost;dbname=piscine;charset=utf8', 'root', 'root');
    
}

catch (Exception $e)
{
        die('Erreur : ' . $e->getMessage());
}

$req = $bdd->prepare('INSERT INTO utilisateurs(email,nom,prenom,pseudo,tel,adresse,password,sex) VALUES(:email,:nom,:prenom,:pseudo,:tel,:adresse,:password,:sex)');

$req->execute(array(
    'email' => $email,
    'nom' => $nom,
    'prenom' => $prenom,
    'pseudo' => $pseudo,
    'tel' => $adresse,
    'password' => $password,
    'sex' => $sex,
    ));



/*

//Connexion a la base de donnée piscine

define('DB_SERVER','localhost'); // initialisation des 3 variables
define('DB_USER','root');
define('DB_PASS','');

$database="piscine"; // nom de la base de données dans le serveur
$db_handle=mysqli_connect(DB_SERVER,DB_USER,DB_PASS) or die('erreur'); // connection a la base 
$db_found=mysqli_select_db($db_handle,$database) or die('Base de donnée introuvable'); // selectionner la base de données sur le serveur


//fonction qui va se charger d'inscrire un nouvel utlisateur

function inscrire_utilisateur($email,$nom,$prenom,$pseudo,$tel,$adresse,$password,$sex)
{
    $sql='INSERT INTO utilisateurs(id,email,nom,prenom,pseudo,tel,adresse,password,sex)
    VALUES('','$email','$nom','$prenom','$pseudo','$tel','$adresse','$password','$sex')';
    
    $password = sha1($password);
    
    mysqli_query($db_handle,$sql) or die('erreur'); // fonction qui accede a l'identificateur de la connection et a la requete precedente
    
    echo ('Nouvel utilisateur ajouté !');
    
    mysqli_close($db_handle);
    
}




*/


?>


