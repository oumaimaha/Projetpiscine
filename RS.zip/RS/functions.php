<?php

//Connexion a la base de donnée piscine

define('DB_SERVER','localhost'); // initialisation des 3 variables
define('DB_USER','root');
define('DB_PASS','');

$database="piscine"; // nom de la base de données dans le serveur
$db_handle=mysqli_connect(DB_SERVER,DB_USER,DB_PASS) or die('erreur'); // connection a la base 
$db_found=mysqli_select_db($db_handle,$database) or die('Base de donnée introuvable'); // selectionner la base de données sur le serveur

//fonction qui va se charger d'inscrire un nouvel utlisateur

function inscrire_utilisateur($pseudo,$password,$email,$sexe,$tel,$adresse)
{
    $password = sha1($password);
    mysql_query("INSERT INTO utilisateurs(pseudo,password,email,sexe,tel,adresse)
    VALUES('','$pseudo','$password','$email','$sexe','$tel','$adresse')
    ") or die(mysql_error());
    
}
?>