<h1>Connexion</h1>

<form method="POST" action=''>

    <label for="pseudo">pseudo : </label>
    <input type="text"name="pseudo"><br/>
    <label for="password">password : </label>
    <input type="password"name="password"><br/><br/>
    <input type="submit"value="Se connecter"name="submit">
    
    
</form>

<a href="index.php?page=register">S'inscire</a>