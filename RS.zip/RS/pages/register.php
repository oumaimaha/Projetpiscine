<h1>Inscription</h1>
<?php
    
    if(isset($_POST['submit']))
    {
        $sexe=mysql_real_escape_string(htmlentities($_POST['sexe']));
        $pseudo=mysql_real_escape_string(htmlentities($_POST['pseudo']));
        $password=mysql_real_escape_string(htmlentities($_POST['password']));
        $repeatpassword=mysql_real_escape_string(htmlentities($_POST['repeatpassword']));
        $email=mysql_real_escape_string(htmlentities($_POST['email']));
        $apropos=mysql_real_escape_string(htmlentities($_POST['apropos']));
        
        if(empty($pseudo))
        {
            $errors[]="Saisir votre pseudo";
        }
        
        if(empty($password))
        {
            $errors[]="Saisir votre password";
        }
        
        if($password!=$repeatpassword)
        {
            $errors[]="Vos passwords doivent être identiques";
        }
        
        if(!filter_var($email,FILTER_VALIDATE_EMAIL))
        {
            $errors[]="Adresse email incorrecte";
        }
        
        if(empty($apropos))
        {
            $errors[]="Veuillez vous décrire brièvement";
        }
        
        if(!empty($errors))
        {
            foreach($errors as $error)
            {
                echo "<div class='error'>".$error."</div>";
            }
        }
    }
?>


<form method="POST" action="">

    <label for="sexe">Sexe</label>
    <select name="sexe">
        
       
        
        
        <option value="Masculin">Masculin</option>
        <option value="Feminin">Feminin</option>
    
    </select><br/><br/>
    
    
    <label for="pseudo">pseudo : </label>
    <input type="text"name="pseudo"><br/>
    
    <label for="password">password : </label>
    <input type="password"name="password"><br/>
    
    <label for="repeatpassword">Repetez votre password : </label>
    <input type="password"name="repeatpassword"><br/>
    
    <label for="email">Saisir votre adresse email : </label>
    <input type="text"name="email"><br/>
    
    <label for="apropos">A propos de vous : </label>
    <textarea rows="6"cols="30"name="apropos"></textarea><br/><br/>
    
    <input type="submit"value="S'inscrire" name="submit">
    
</form>


<a href="index.php?page=login">Retour à la page de connexion</a>


    
    