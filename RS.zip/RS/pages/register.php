<h1>Inscription</h1>
<?php
    
    if(isset($_POST['submit']))
    {
        $sexe=mysql_real_escape_string(htmlspecialchars(trim($_POST['sexe'])));
        $pseudo=mysql_real_escape_string(htmlentities(trim($_POST['pseudo'])));
        $password=mysql_real_escape_string(htmlentities(trim($_POST['password'])));
        $repeatpassword=mysql_real_escape_string(htmlentities(trim($_POST['repeatpassword'])));
        $email=mysql_real_escape_string(htmlentities(trim($_POST['email'])));
        $tel=mysql_real_escape_string(htmlentities(trim($_POST['tel'])));
        $adresse=mysql_real_escape_string(htmlentities(trim($_POST['adresse'])));
       
        
        if(empty($pseudo))
        {
            $errors[]="Saisir votre pseudo";
        }
        
        if(empty($password))
        {
            $errors[]="Saisir votre password";
        }
        
        if($password!=$repeatpassword)
        {
            $errors[]="Vos passwords doivent être identiques";
        }
        
        if(!filter_var($email,FILTER_VALIDATE_EMAIL))
        {
            $errors[]="Adresse email incorrecte";
        }
        
        if(empty($tel))
        {
            $errors[]="Saisir votre numero de telephone";
        }
        
        if(empty($adresse))
        {
            $errors[]="Saisir votre adresse";
        }
        
        if(!empty($errors))
        {
            foreach($errors as $error)
            {
                echo "<div class='error'>".$error."</div>";
            }
        }else
        {
            inscrire_utilisateur($pseudo,$password,$email,$sexe,$tel,$adresse);
             die ('Vous êtes désormais inscrit, vous pouvez maintenant vous <a href=\'index.php?page=login\'>connecter</a>');
        }
            
    }
?>


<form method="POST" action="">

    <label for="sexe">Sexe</label>
    <select name="sexe">
        
        <?php 
           echo isset($sexe)?'<option value='.$sexe.'>'.$sexe.'</option>':'';
        ?>
        
     
        <?php
            echo $sexe != 'Masculin' ? '<option value="Masculin">Masculin</option>':'';
        ?>
        
        <?php
            echo $sexe != 'Feminin' ? '<option value="Feminin">Feminin</option>':'';
        ?>
        
    
    </select><br/><br/>
    
    
    <label for="pseudo">pseudo</label>
    <input type="text"name="pseudo"value='<?php echo isset($pseudo)?$pseudo:'';?>'><br/>
    
    <label for="password">password</label>
    <input type="password"name="password"><br/>
    
    <label for="repeatpassword">Repetez votre password</label>
    <input type="password"name="repeatpassword"><br/>
    
    <label for="email">email</label>
    <input type="text"name="email" value='<?php echo isset($email)?$email:'';?>'><br/>
    
    <label for="tel">numero de telephone</label>
    <input type="tel"name="tel"><br/><br/>
    
    <label for="adresse">adresse</label>
    <input type="adresse"name="adresse"><br/>
    
    
    
    
    <input type="submit"value="S'inscrire" name="submit">
    
</form>


<a href="index.php?page=login">Retour à la page de connexion</a>


    
    