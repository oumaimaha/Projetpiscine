

<?php

$page=htmlentities($_GET['page']);

$pages=scandir('pages');


if(!empty($page)&&in_array($_GET['page'].".php",$pages))
{
    $content='pages/'.$_GET['page'].".php";
}else
{
    header("Location:index.php?page=login");
}


?>


<!DOCTYPE html>
<html>
 <head>
    <link rel="stylesheet" href="css/style.css"/>
 </head>
    <body>
        
        <div id="header">
        <figure>
            <img src="logo.jpg" alt="Logo View" width="150" height="200" padding="250px" >
        </figure>
        </div>
        
        <div id="content">
             <?php
                include($content); 
             ?>
            
        <div id="chercher">
            <form method="POST" action="">

        <br/><br/><br/>
                  
        <div id="trait"><hr></div><br/>
                
    <h3>Rechercher une personne</h3>
            
        <figure>
            <img src="loupe.jpg" alt="Loupe View" width="60" height="50"  >
        </figure>
    
    <label for="nom">Nom</label>
    <input type="text" name="nom"><br/>
    <label for="prenom">Prenom </label>
    <input type="text" name="prenom"><br/><br/>
    <input type="submit" value="Chercher" name="chercher">
    
        </form>   
    </div>
            
        </div>
        
         <div id="footer">
            Droit d'auteur | Copyright &copy; 2018 Projet Piscine
        </div> 
           
    </body>
</html>

