
<h1>Inscription</h1>
<?php
    $pseudo  =isset($_POST["pseudo"])?$_POST["pseudo"]:"";//if then else
    
    $password = isset($_POST["password"])?$_POST["password"]:"";
    $repeatpassword= isset($_POST["repeatpassword"])?$_POST["repeatpassword"]:"";
    $email = isset($_POST["email"])?$_POST["email"]:"";
    $apropos= isset($_POST["apropos"])?$_POST["apropos"]:"";
   if(isset($_POST['submit'])){
    //Blindage de la saisie des infos
    

    if(empty($pseudo)){$erreurs[] ="pseudo non renseigné<br/>";}
    if(empty($password)){$erreurs[]="Saisir votre password";}
    if($password!=$repeatpassword){$erreurs[]="Vos passwords doivent être identiques";}
     if(empty($apropos)){$erreurs[]="Veuillez vous décrire brièvement";}
     if(!filter_var($email,FILTER_VALIDATE_EMAIL)){$erreurs[]="Adresse email incorrecte";}
    
     if(!empty($erreurs))
        {
            foreach($erreurs as $erreur)
            {
                echo "<div class='erreur'>".$erreur."</div>";
            }
    /*if($password == ""){$erreur .="password d'identification non renseigné<br/>";}
    if($repeatpassword == ""){$erreur .="repeatpassword non renseignée<br/>";}
    if($email == ""){$erreur .="email non renseignée<br/>";}
    if($apropos == ""){$erreur .="décrivez vous brievement<br/>";}
    */

   /* if($erreur==""){
        echo "Formulaire valide";
    }
    else{
        echo "Erreur : $erreur";
    }*/
}
}
    
    ?>
<form method="POST" action="">

    <label for="sexe">Sexe</label>
    <select name="sexe">
        
    <option value="Masculin">Masculin</option>
     <option value="Feminin">Feminin</option>
    
    </select><br/><br/>
    
    
    <label for="pseudo">pseudo : </label>
    <input type="text" name="pseudo" ><br/>
    
    <label for="password">password : </label>
    <input type="password"name="password"><br/>
    
    <label for="repeatpassword">Repetez votre password : </label>
    <input type="password"name="repeatpassword"><br/>
    
    <label for="email"> Saisir votre adresse email : </label>
    <input type="text" name="email"> <br/>
    
    <label for="apropos">A propos de vous : </label>
    <textarea rows="6"cols="30"name="apropos"></textarea><br/><br/>
    
    <input type="submit"value="S'inscrire" name="submit">
    
</form>


<a href="index.php?page=login">Retour à la page de connexion</a>



    
    